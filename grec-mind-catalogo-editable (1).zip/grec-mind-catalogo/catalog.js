/*
  DATOS DE GREC MIND — EDITA AQUÍ TUS DATOS Y PRODUCTOS.
  WhatsApp en formato internacional, solo números: 51 + número de Perú.
*/
const STORE = {
  name: "Grec Mind",
  whatsapp: "51967964900",
  currency: "S/",
  instagram: "https://www.instagram.com/grec.mind/",
  payment: "Yape",
  shipping: "Envíos por Shalom y entregas en Lima"
};

/*
  AGREGA TUS PRENDAS en PRODUCTS.
  image: foto dentro de assets/productos/
  category: por ejemplo "Vestidos", "Conjuntos", "Pijamas" o "Lencería".
  price: precio numérico.
*/
const PRODUCTS = [
  // Ejemplo: elimina las barras // y reemplaza los datos por los de tu prenda.
  // {
  //   name: "Vestido Aura",
  //   category: "Vestidos",
  //   price: 89.90,
  //   image: "assets/productos/vestido-aura.jpg",
  //   description: "Tallas S, M y L"
  // },
];
